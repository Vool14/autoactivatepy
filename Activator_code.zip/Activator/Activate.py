#AutoActivatePy
#VladPySuper (vool14) on github
#github: https://github.com/Vool14

import os
import time

print ("#AutoActivatePy")
print("#VladPySuper (vool14) on github")
print ("#github: https://github.com/Vool14")
print ("Starting...")
time.sleep(3)
print ("Please press yes!")
time.sleep(5)

os.system("win.cmd")
time.sleep(5)
os.system("of.cmd")
input()
